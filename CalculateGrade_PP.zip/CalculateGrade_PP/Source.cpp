#include <iostream>
#include <vector>
#include <string>
using namespace std;

//This program will calculate my calc grade. 

int main()
{
	int choice, num;
	double grade, sum;
	double WP;
	bool FG;

	// FOllowing will allow users to enter there own groups
	string VarInput;
	vector<string> Catagory;
	int CatNum;

	// Will be the out of loop variables that will sum up the grade averages and weights.
	double GlobalG, GlobalW;
	GlobalG = 0;
	double CurrentGrade;//The calculation of current grade;
	GlobalW = 0;
	FG = false;
	bool test;// checks if number of grades to input is greater than one. Didnt really need in hindsight.
	bool main = true;// breaks out of program once youve recieved current grade.
	int z = 0;

	cout << "Please enter the number of catagories you wish to calculate ";
	cin >> CatNum;
	cin.ignore();
	for (int i = 0; i < CatNum; i++)
	{
		cout << "Please enter the group name ";
		getline(cin, VarInput);
		Catagory.push_back(VarInput);
	}

	while (main)
	{
		for (string Cat : Catagory)
		{
			z++;
			cout << z << ". " << Cat << "\n";
		}
		choice = 0;
		z = 0;
		cout << Catagory.size()+1 << ". Calculate Grade \n";

		cin >> choice;

		if (choice != Catagory.size() + 1)
		{
			for (int i = 0; i < 1; i++)
			{
				cout << "How many grades do you wish to input? ";
				cin >> num;
				if (num < 1)
					test = true;
				else
					test = false;
				while (test == true)
				{
					cout << "Please enter a value greater than 1 to continue, else, enter 0 to exit.";
					cin >> num;
					if (num >= 0)
						test = false;
				}
				sum = 0;
				for (int A = 0; A < num; A++)
				{
					cout << "Please input a grade for " << Catagory[choice-1];
					cin >> grade;
					if (grade < 1)
					{
						grade = grade * 100;
					}
					sum = sum + grade;
				}
				cout << "What percentage does this weigh? ";
				cin >> WP;
				if (WP > 1)
					WP /= 100;
				sum /= num;
				GlobalG += (sum *WP);
				GlobalW += WP;
				break;
			}
		}

		
		if (Catagory.size()+1 == choice)
		{
			CurrentGrade = GlobalG / GlobalW;
			cout << "Your grade in this class is " << CurrentGrade << ".\n";
			main = false;
			break;
		}
	}
}
